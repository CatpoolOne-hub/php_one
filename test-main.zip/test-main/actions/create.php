<?

require_once '../config/connect.php';

$name = $_POST['name'];
$surname = $_POST['surname'];
$phone = $_POST['phone'];
$country = $_POST['country'];
$image_url =$_POST['image_url'] ;
  $pattern = "/^\+380\d{3}\d{2}\d{2}\d{2}$/";
  if(preg_match($pattern, $phone)) {
  mysqli_query($connect,"INSERT INTO `users` (`id`, `name`, `surname`, `phone`, `country`, `image_url`) VALUES (NULL, '$name', '$surname', '$phone', '$country', '$image_url')");
  header('Location: /');
  }
  
  else echo "Телефон введён некоректно";




