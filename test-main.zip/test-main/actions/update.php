<?php
require_once '../config/connect.php';

$id = $_POST['id'];
$name = $_POST['name'];
$surname = $_POST['surname'];
$phone = $_POST['phone'];
$country = $_POST['country'];
$image_url = $_POST['image_url'];



mysqli_query($connect, "UPDATE `users` SET `name` = '$name', `surname` = '$surname', `phone` = '$phone', `country` = '$country', `image_url` = '$image_url'  WHERE `users`.`id` = '$id'");

header('Location: /');