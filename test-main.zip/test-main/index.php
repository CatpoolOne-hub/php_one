<?php
require_once 'config/connect.php';
echo "<link rel='stylesheet' href='style.css'>";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Сотрудники</title>
</head>
<body>
  <div class="container">
    <div class="table-staff">
    <table>
        <tr>
            <th>id</th>
            <th>Имя</th>
            <th>Фамилия</th>
            <th>Телефон</th>
            <th>Страна</th>
            <th>Изображение</th>
            <th>Изменить</th>
            <th>Удалить</th>
        </tr>

        <?php
            $users = mysqli_query($connect, "SELECT * FROM `users`");
            $users = mysqli_fetch_all($users);

            foreach ($users as $user) {
                ?>
                    <tr>
                        <td><?=$user[0] ?></td>
                        <td><?= $user[1] ?></td>
                        <td><?= $user[2] ?></td>
                        <td><?= $user[3] ?></td>
                        <td><?= $user[4] ?></td>
                        <td><img class="image" src="<?=$user[5]?>"></td>
                        <td><a href="update.php?id=<?= $user[0] ?>">Изменить</a></td>
                        <td><a href="actions/delete.php?id=<?= $user	[0] ?>">Удалить</a></td>
                    </tr>
                <?php
            }
        ?>
    </table>
    </div>
    <div class="form">
    <h3>Добавить нового сотрудника</h3>
    <form action="actions/create.php" enctype="multipart/form-data" method="post">
        <div>Имя</br></div>
        <input type="text" name="name">
        <div>Фамилия</br></div>
        <input name="surname">
        <div>Телефон</br></div>
        <input type="text" name="phone" placeholder="+380 12 3456 7890">
        <div>Страна</br></div>
        <input type="text" name="country">
        <div>Изображание</br></div>
         <input type="text" name="image_url">
         </br> </br>
       <!--  <input type="file" name="image"> 
          </br> </br>-->
        <button type="submit">Добавить
    </form>
    </div>
  </div>
</body>
</html>