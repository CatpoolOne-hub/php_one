<?php


    require_once 'config/connect.php';
    $user_id = $_GET['id'];

    $user = mysqli_query($connect, "SELECT * FROM `users` WHERE `id` = '$user_id'");

    $user = mysqli_fetch_assoc($user);
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Изменение сотрудника</title>
</head>
<body>
    <h3>Изменение информации о сотруднике</h3>
    
    <form action="actions/update.php" method="post">
        <input type="hidden" name="id" value="<?= $user['id'] ?>">
        <div>Имя</br></div>
        <input type="text" name="name" value="<?= $user['name'] ?>">
        <div>Фамилия</br></div>
        <input type="text" name="surname" value="<?= $user['surname'] ?>">
        <div>Телефон</br></div>
        <input type="text" name="phone" value="<?= $user['phone'] ?>"> 
        <div>Страна</br></div>
        <input type="text" name="country" value="<?= $user['country'] ?>">
        <div>Изображание</br></div>
        <input type="text" name="image_url" value="<?= $user['image_url'] ?>">
        <br> <br>
        <button type="submit">Обновить</button>
    </form>
   
</body>
</html>