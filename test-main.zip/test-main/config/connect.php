<?php

$connect = mysqli_connect('localhost', 'mysql', 'mysql', 'test_db');

if (!$connect) {
    die('Ошибка подключения к дб');
}